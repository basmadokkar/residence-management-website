<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "bdd1";
$conn = mysqli_connect($host,$username,$password,$dbname);
if(!$conn) {
die("La connection a echoué:".mysqli_connect_error());}
else{
echo "Connecté...";
}
$prenom = $_POST['prenom'];
$nom = $_POST['nom'];
$num = $_POST['num'];
$email = $_POST['email'];
$tel = $_POST['tel'];
$sql = "INSERT INTO etudiante (prenom,nom,num,email,tel) VALUES ('$prenom','$nom','$num','$email','$tel')";
if(!mysqli_query($conn,$sql))
	echo 'les valeurs nont pas etaient inserées';
else
	echo 'les valeurs ont etaient inserées ';
 ?>